
import pymongo
print "hello";

from pymongo import MongoClient
client = MongoClient()

db = client.yelp

record_count = db.yelp_business.find({'state':'AZ'}).count()
#print record_count   

records_AZ  = db.yelp_business.find({'state':'AZ'}).limit(3754);

#for records_AZ, val in enumerate(records_AZ):
#    print val
    
ids = [val['business_id'] for val in records_AZ]
#print ids

#checkins = []
#for id in ids:
#    current_rec = db.yelp_checkin.find_one({'business_id': id})
#    if current_rec == None:
#        continue
#    #print current_rec
#    checkins.append(current_rec)
#    break

#print (checkins)

#AZ - Tuesday evening
checkins = []
for id in ids:
    current_rec = db.yelp_checkin.find_one({ "$and": [{"business_id":id}, { "$or": [{"checkin_info.18-2":{"$gte":1}},{"checkin_info.19-2":{"$gte":1}},{"checkin_info.20-2":{"$gte":1}},{"checkin_info.21-2":{"$gte":1}},{"checkin_info.22-2":{"$gte":1}},{"checkin_info.23-2":{"$gte":1}}]}] })
    if current_rec == None:
        continue
    #print current_rec
    checkins.append(current_rec)
    #break

#print (checkins)

ids_time_day = [val['business_id'] for val in checkins]
#print ids_time_day
print "28,29,20,22,22,23 - 2(Tuesday-Eve:18:00-24:00PM)",len(ids_time_day)


#AZ - Tuesday afternoon
checkin_afternoon = []
for id in ids:
    current_rec_after = db.yelp_checkin.find_one({ "$and": [{"business_id":id}, { "$or": [{"checkin_info.12-2":{"$gte":1}},{"checkin_info.13-2":{"$gte":1}},{"checkin_info.14-2":{"$gte":1}},{"checkin_info.15-2":{"$gte":1}},{"checkin_info.16-2":{"$gte":1}},{"checkin_info.17-2":{"$gte":1}}]}] })
    if current_rec_after == None:
        continue
    #print current_rec_after
    checkin_afternoon.append(current_rec_after)
    #break

#print (checkin_afternoon)

ids_time_day_new = [val['business_id'] for val in checkin_afternoon]
#print ids_time_day_new
print "12,13,14,15,16,17 - 2(Tuesday-Afternoon:12:00-6:00PM)",len(ids_time_day_new)


#AZ - Tuesday morning
checkin_morning = []
for id in ids:
    current_rec_morning = db.yelp_checkin.find_one({ "$and": [{"business_id":id}, { "$or": [{"checkin_info.6-2":{"$gte":1}},{"checkin_info.7-2":{"$gte":1}},{"checkin_info.8-2":{"$gte":1}},{"checkin_info.9-2":{"$gte":1}},{"checkin_info.10-2":{"$gte":1}},{"checkin_info.11-2":{"$gte":1}}]}] })
    if current_rec_morning == None:
        continue
    #print current_rec_morning
    checkin_morning.append(current_rec_morning)
    #break

#print (checkin_morning)

ids_time_day_morning = [val['business_id'] for val in checkin_morning]
#print ids_time_day_morning
print "6,7,8,9,10,11 - 2(Tuesday-Morning:6:00-11:59AM)",len(ids_time_day_morning)


total_business = len(ids_time_day_new)+len(ids_time_day_morning)+len(ids_time_day)
print "total business visited on Tuesday",total_business




